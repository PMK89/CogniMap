export class CMColorbar {
  public id: number;
  public name: string;
  public group: string;
  public cat: string;
  public prio: number;
  public variable: string[];
  public colors: string[];
  public cuppled: boolean;
  public secured: boolean;
  public blocked: boolean;
}
