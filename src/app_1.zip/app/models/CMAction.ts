export class CMAction {
  public variable: string[];
  public value: any;
}
