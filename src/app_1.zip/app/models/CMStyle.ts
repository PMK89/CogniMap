export class CMStyle {
  name: string;
  font: string;
  fontcolor: string;
  fontsize: number;
  bgcolor: string;
  linecolor: string;
  shadowcolor: string;
  boxclass: string;
  btnbgcolor0: string;
  btnbgcolor1: string;
  btnclickcolor: string;
  btndeactcolor: string;
  btncontentcolor: string;
  btnbordercolor: string;
  btnclass: string;
}
