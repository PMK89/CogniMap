
export class CMTBLine {
  public color0: string;
  public color1: string;
  public size0: [string];
  public size1: [string];
  public zPos: [string];
  public trans: [string];
  public buttons: string;
}
