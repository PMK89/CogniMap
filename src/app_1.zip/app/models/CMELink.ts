
export class CMELink {
  public id: number;
  public targetId: number;
  public title: string;
  public weight: number;
  public con: string;
  public start: boolean;
}
