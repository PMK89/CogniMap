export class CMTBFont {
  public color: string;
  public size: [string];
  public font: [string];
  public buttons: string;
}
