export class CMCoor {
  x: number;
  y: number;
}
