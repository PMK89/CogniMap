export class Boundaries {
    l: number;
    r: number;
    t: number;
    b: number;
}
