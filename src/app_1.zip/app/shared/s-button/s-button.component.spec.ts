/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SButtonComponent } from './s-button.component';

describe('Component: SButton', () => {
  it('should create an instance', () => {
    let component = new SButtonComponent();
    expect(component).toBeTruthy();
  });
});
