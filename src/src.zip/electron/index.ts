const electron = (<any> window).require('electron');

export const { BrowserWindowProxy } = electron;
export const { desktopCapturer } = electron;
export const { ipcRenderer } = electron;
export const { remote } = electron;
export const { webFrame } = electron;
