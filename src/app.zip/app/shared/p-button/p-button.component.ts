import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p-button',
  templateUrl: './p-button.component.html',
  styleUrls: ['./p-button.component.scss']
})
export class PButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
