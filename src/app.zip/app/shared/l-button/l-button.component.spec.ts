/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SButtonComponent } from './l-button.component';

describe('Component: LButton', () => {
  it('should create an instance', () => {
    let component = new LButtonComponent();
    expect(component).toBeTruthy();
  });
});
