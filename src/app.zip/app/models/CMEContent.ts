import { CMCoor } from './CMCoor';

export class CMEContent {
  public cat: string;
  public coor: CMCoor;
  public object: string;
  public info: string;
  public width: number;
  public height: number;
}
