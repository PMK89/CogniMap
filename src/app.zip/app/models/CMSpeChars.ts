export class CMSpeChars {
  public greek: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
  public arrows: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
  public math: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
  public numbers: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
  public common: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
  public lastused: {
    chars0: string[];
    chars1: string[];
    chars2: string[];
  };
}
