export class SBBox {
    cx: number;
    cy: number;
    h: number;
    height: number;
    path: string;
    r0: number;
    r1: number;
    r2: number;
    vb: string;
    w: number;
    width: number;
    x2: number;
    x: number;
    y2: number;
    y: number;
}
