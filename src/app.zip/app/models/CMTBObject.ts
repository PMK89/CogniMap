
export class CMTBObject {
  public color0: string;
  public color1: string;
  public zPos: [string];
  public trans: [string];
  public buttons: string;
}
