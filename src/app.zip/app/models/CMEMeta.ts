export class CMEMeta {
  public name: string;
  public cat: string;
  public content: string;
  public comment: string;
}
