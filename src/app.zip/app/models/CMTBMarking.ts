
export class CMTBMarking {
  public color0: string;
  public color1: string;
  public prio: number;
  public trans: number;
  public types: [string];
}
