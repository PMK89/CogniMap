export class CMButton {
  public id: number;
  public btntype: string;
  public name: string;
  public group: string;
  public cat: string;
  public prio: number;
  public variable: [string];
  public value: string;
  public contenttype: string;
  public content: string;
  public blocked: boolean;
  public active: boolean;
}
